package com.howard.audit.domain;

public enum TradeType {
    SALE,
    PURCHASE
}
