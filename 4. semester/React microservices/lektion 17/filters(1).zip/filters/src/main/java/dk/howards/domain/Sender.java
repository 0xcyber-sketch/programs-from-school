package dk.howards.domain;

public class Sender {
    private final String name;

    public Sender(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
