package com.howard.authentication.domain;

public interface Credential {
    String getValue();
}
