package com.howard.authentication.domain;

public enum Role {
    USER,
    ADMIN,
    SUPER_USER
}
