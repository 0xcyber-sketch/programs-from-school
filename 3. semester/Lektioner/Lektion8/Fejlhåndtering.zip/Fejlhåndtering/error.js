// error.js
throw 'Dette er en string som exception';
// => Dette er en string som exception
throw Error('Dette er en Error som exception');
// => Error: Dette er en Error som exception
//     at Object.<anonymous> (c:\Users\ed\...\error.js:4:7)
//     at ...