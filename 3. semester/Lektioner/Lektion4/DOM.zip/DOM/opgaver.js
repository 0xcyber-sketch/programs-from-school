// Tilføj kode for opgave 4.1 - 4.5 her!
