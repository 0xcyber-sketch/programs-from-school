// window.js
x = 1;
var y = 2;
let z = 3;
const u = 4;
function f() {}
console.log(window);
console.log(x, y, z, u);