let config = {}
config.mongoDBHost = 'mongodb+srv://ksd:H08tg4w7roBdAWb9@test-hc4ch.gcp.mongodb.net/test?retryWrites=true&w=majority'
config.PORT = 3000
module.exports = config