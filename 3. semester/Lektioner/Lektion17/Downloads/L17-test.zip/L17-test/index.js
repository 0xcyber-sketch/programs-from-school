exports.add = (x,y) => {
  return x + y
}

exports.subtract = (x,y) => {
  return x - y
}