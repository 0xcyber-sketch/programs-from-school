// input.js
let knap = document.querySelector("button");
let input = document.querySelector("input");

knap.onclick = () => input.value++;